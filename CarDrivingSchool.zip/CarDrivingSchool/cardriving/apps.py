from django.apps import AppConfig


class CardrivingConfig(AppConfig):
    name = 'cardriving'
