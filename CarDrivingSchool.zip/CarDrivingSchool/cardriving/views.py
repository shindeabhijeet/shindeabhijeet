from django.db.models import Q
from django.shortcuts import render,redirect
from .models import *
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
from django.contrib import messages
from datetime import date
from datetime import datetime, timedelta, time
import random
from django.db.models import Sum

def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

def enquiry(request):
    error = ""
    if request.method == 'POST':
        fn = request.POST['fullname']
        em = request.POST['email']
        mn = request.POST['mobilenumber']
        enq = request.POST['enquiry']
        try:
            Contact.objects.create(name=fn,mobilenumber=mn,emailid=em,message=enq,enquirydate=date.today(),isread="no")
            error = "no"
        except:
            error = "yes"
    d = {'error': error}
    return render(request, 'enquiry.html', d)


def apply_form(request):
    error = ""
    package = Packages.objects.all()
    regn = ""
    if request.method == 'POST':
        pack = request.POST['packages']
        trdate = request.POST['trainingdate']
        trtime = request.POST['time']
        fn = request.POST['fullname']
        em = request.POST['email']
        mn = request.POST['mobilenumber']
        gen = request.POST['gender']
        age = request.POST['age']
        licn = request.POST['licno']
        licp = request.FILES['licpic']
        addr = request.POST['address']
        altno = request.POST['altnumber']
        packageid = Packages.objects.get(id=pack)
        regn = str(random.randint(10000000, 99999999))
        try:
            tblUser.objects.create(packageid=packageid,regnumber=regn,fullname=fn,emailid=em,mobileno=mn,gender=gen,age=age,licenceno=licn,licenceimage=licp,address=addr,alternateno=altno,trainingdate=trdate,trainingtime=trtime,status="Pending",regdate=date.today())
            error = "no"
        except:
            error = "yes"
    d = {'error': error,'package': package,'regn':regn}
    return render(request, 'apply_form.html', d)





def admin_login(request):
    error = ""
    if request.method == 'POST':
        u = request.POST['username']
        p = request.POST['password']
        user = authenticate(username=u, password=p)
        try:
            if user.is_staff:
                login(request,user)
                error = "no"
            else:
                error = "yes"
        except:
            error = "yes"
    d = {'error': error}
    return render(request, 'admin_login.html',d)


def dashboard(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    usercount = tblUser.objects.all().count()
    packagecount = Packages.objects.all().count()
    contactcount = Contact.objects.all().count()

    d = {'usercount': usercount,'packagecount':packagecount,'contactcount':contactcount,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request, 'dashboard.html',d)


def add_package(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")
    error = ""
    if request.method=="POST":
        pn = request.POST['packname']
        pdes = request.POST['packdes']
        pdur = request.POST['packduration']
        pp = request.POST['packprice']

        try:
            Packages.objects.create(packagename=pn,description=pdes,duration=pdur,price=pp)
            error = "no"
        except:
            error = "yes"
    d = {'error':error,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request, 'add_package.html', d)


def manage_package(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')

    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    package = Packages.objects.all()
    d = {'package':package,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request, 'manage_package.html', d)


def edit_packagedetail(request,pid):
    if not request.user.is_authenticated:
        return redirect('index')
    package = Packages.objects.get(id=pid)
    error = ""

    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    if request.method == 'POST':
        pn = request.POST['packname']
        pdes = request.POST['packdes']
        pdur = request.POST['packduration']
        pp = request.POST['packprice']

        package.packagename = pn
        package.description = pdes
        package.duration = pdur
        package.price = pp
        try:
            package.save()
            error = "no"
        except:
            error = "yes"
    d = {'package':package,'error':error,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request, 'edit_packagedetail.html', d)

def Logout(request):
    logout(request)
    return redirect('index')


def package(request):
    package = Packages.objects.all()

    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    d = {'package':package,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request, 'package.html', d)


def new_reg(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    user = tblUser.objects.filter(status="Pending")

    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    d = {'user':user,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request,'new_reg.html', d)

def old_reg(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')

    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    user = tblUser.objects.filter(~Q(status="Pending"))
    d = {'user':user,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request,'new_reg.html', d)



def user_detail(request,pid):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    user = tblUser.objects.get(id=pid)
    payment = tblPayment.objects.filter(userid=user)
    paymentcount = tblPayment.objects.filter(userid=user).count()
    total = tblPayment.objects.filter(userid=user).aggregate(Sum('paymentamount'))
    totalpay = 0
    for i in payment:
        totalpay = totalpay + int(i.paymentamount)

    rem =  int(user.packageid.price) - totalpay
    error = ""
    if request.method == 'POST':
        rem = request.POST['remark']
        df =  request.POST['depositfee']
        st = request.POST['status']
        user.status = st
        try:
            user.save()
            tblPayment.objects.create(userid=user,paymentamount=df,remark=rem,paymentstatus=st,paymentdate=date.today())
            error = "no"
        except:
            error = "yes"
    d = {'user':user,'error':error,'payment':payment,'paymentcount':paymentcount,'total':total,'rem':rem,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request,'user_detail.html', d)


def read_enquiry(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')

    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    contact = Contact.objects.filter(isread="yes")
    contactcount = Contact.objects.filter(isread="yes").count()
    d = {'contact': contact,'contactcount':contactcount,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request, 'read_enquiry.html', d)


def unread_enquiry(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')

    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    contact = Contact.objects.filter(isread="no")
    contactcount = Contact.objects.filter(isread="no").count()
    d = {'contact': contact,'contactcount':contactcount,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request, 'unread_enquiry.html', d)

def view_enquiry(request,pid):
    if not request.user.is_authenticated:
        return redirect('admin_login')

    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    contact = Contact.objects.get(id=pid)
    contact.isread = "yes"
    contact.save()
    d = {'contact': contact,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request, 'view_enquiry.html', d)


def search(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    usercount = 0
    user=""
    sd=""
    click="no"
    if request.method == "POST":
        click="yes"
        sd = request.POST['searchdata']
        user = tblUser.objects.filter(regnumber=sd)
        usercount = tblUser.objects.filter(regnumber=sd).count()

    d = {'user':user,'usercount':usercount,'sd':sd,'click':click,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request,'search.html',d)



def betweendate_reportdetails(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')

    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")
    d = {'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
    return render(request, 'betweendate_reportdetails.html',d)



def betweendate_report(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')

    newcontactcount = Contact.objects.filter(isread="no").count()
    newusercount = tblUser.objects.filter(status="Pending").count()
    newcontact = Contact.objects.filter(isread="no")
    newuser = tblUser.objects.filter(status="Pending")

    if request.method == "POST":
        fd = request.POST['fromdate']
        td = request.POST['todate']
        user = tblUser.objects.filter(Q(regdate__gte=fd) & Q(regdate__lte=td))
        usercount = tblUser.objects.filter(Q(regdate__gte=fd) & Q(regdate__lte=td)).count()
        d = {'user': user,'fd':fd,'td':td,'usercount':usercount,'newcontactcount':newcontactcount,'newusercount':newusercount,'newcontact':newcontact,'newuser':newuser}
        return render(request, 'betweendate_reportdetails.html', d)
    return render(request, 'betweendate_report.html')


def change_password(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    error = ""
    if request.method=="POST":
        o = request.POST['currentpassword']
        n = request.POST['newpassword']
        c = request.POST['confirmpassword']
        if c == n:
            u = User.objects.get(username__exact=request.user.username)
            u.set_password(n)
            u.save()
            error = "yes"
        else:
            error = "not"
    d = {'error':error}
    return render(request,'change_password.html',d)
