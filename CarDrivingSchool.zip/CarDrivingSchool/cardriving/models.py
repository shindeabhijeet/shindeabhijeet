from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Contact(models.Model):
    name = models.CharField(max_length=50)
    mobilenumber = models.CharField(max_length=10)
    emailid = models.CharField(max_length=100)
    message = models.CharField(max_length=500)
    enquirydate = models.DateField()
    isread = models.CharField(max_length=10)
    def __str__(self):
        return self.name

class Packages(models.Model):
    packagename = models.CharField(max_length=100)
    description = models.CharField(max_length=500)
    duration = models.CharField(max_length=50)
    price = models.CharField(max_length=50)
    postingdate = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.packagename



class tblUser(models.Model):
    packageid = models.ForeignKey(Packages, on_delete=models.CASCADE)
    regnumber = models.CharField(max_length=10)
    fullname = models.CharField(max_length=100)
    emailid = models.CharField(max_length=50)
    mobileno = models.CharField(max_length=10)
    gender = models.CharField(max_length=20)
    age = models.CharField(max_length=50)
    licenceno = models.CharField(max_length=20)
    licenceimage = models.FileField()
    address = models.CharField(max_length=200)
    alternateno = models.CharField(max_length=10)
    trainingdate = models.DateField()
    trainingtime = models.TimeField()
    status = models.CharField(max_length=30)
    regdate = models.DateField()

    def __str__(self):
        return self.regnumber

class tblPayment(models.Model):
    userid = models.ForeignKey(tblUser, on_delete=models.CASCADE)
    paymentamount = models.CharField(max_length=20)
    remark = models.CharField(max_length=200)
    paymentstatus = models.CharField(max_length=50)
    paymentdate = models.DateField()
    def __str__(self):
        return self.paymentamount


