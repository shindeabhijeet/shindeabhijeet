"""CarDrivingSchool URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from cardriving.views import *
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',index, name='index'),
    path('about',about, name='about'),
    path('contact',contact, name='contact'),
    path('enquiry',enquiry, name='enquiry'),
    path('admin_login',admin_login, name='admin_login'),
    path('dashboard',dashboard, name='dashboard'),
    path('add_package',add_package, name='add_package'),
    path('manage_package',manage_package, name='manage_package'),
    path('edit_packagedetail/<int:pid>',edit_packagedetail, name='edit_packagedetail'),
    path('logout',Logout, name='logout'),
    path('package',package, name='package'),
    path('apply_form',apply_form, name='apply_form'),
    path('new_reg',new_reg, name='new_reg'),
    path('old_reg',old_reg, name='old_reg'),
    path('user_detail/<int:pid>',user_detail, name='user_detail'),
    path('read_enquiry',read_enquiry, name='read_enquiry'),
    path('unread_enquiry',unread_enquiry, name='unread_enquiry'),
    path('view_enquiry/<int:pid>',view_enquiry, name='view_enquiry'),
    path('search',search, name='search'),
    path('betweendate_report',betweendate_report, name='betweendate_report'),
    path('betweendate_reportdetails',betweendate_reportdetails, name='betweendate_reportdetails'),
    path('change_password',change_password, name='change_password'),
]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
